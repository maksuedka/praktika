package by.ggpk.app.enums;

public enum Size {

    S, M, L, XL, XXL, XXXL, XS, XXS
}
