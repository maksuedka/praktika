package by.ggpk.app.dto;

import by.ggpk.app.enums.ProductCategory;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class ProductDto {

    private Long id;
    private String name;
    private ProductCategory category;
    private BigDecimal price;
    private String imageUrl;
    private List<StockDto> stock;

}
