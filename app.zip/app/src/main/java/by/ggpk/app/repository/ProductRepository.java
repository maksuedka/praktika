package by.ggpk.app.repository;


import by.ggpk.app.entity.Product;
import by.ggpk.app.enums.ProductCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductRepository extends JpaRepository<Product, Long> {

    @Query("SELECT p FROM Product p LEFT JOIN FETCH p.stock s")
    List<Product> findAllWithStock();

    @Query("SELECT p FROM Product p LEFT JOIN FETCH p.stock s WHERE p.category = :category")
    List<Product> findAllWithStockByCategory(ProductCategory category);
}
