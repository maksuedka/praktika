package by.ggpk.app.controller;

import by.ggpk.app.dto.ProductDto;
import by.ggpk.app.enums.ProductCategory;
import by.ggpk.app.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/products")
    public List<ProductDto> getAllProducts(@RequestParam(required = false) ProductCategory category) {
        return productService.getAllProducts(category);
    }

}
