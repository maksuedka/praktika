package by.ggpk.app.dto;

import by.ggpk.app.enums.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StockDto {

    private Size size;
    private Integer quantity;
}
