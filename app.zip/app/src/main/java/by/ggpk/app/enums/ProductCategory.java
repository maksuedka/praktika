package by.ggpk.app.enums;

public enum ProductCategory {

    JEANS, SHORTS, TROUSERS
}
