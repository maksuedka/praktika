
CREATE TABLE product (
  "id" BIGSERIAL PRIMARY KEY,
  "name" varchar(100) NOT NULL,
  "category" varchar(100) NOT NULL,
  "price" BIGINT NOT NULL,
  "image_url" VARCHAR(2048) NULL
);

CREATE TABLE stock (
  "id" BIGSERIAL PRIMARY KEY,
  "product_id" BIGSERIAL NOT NULL,
  "size" varchar(4) NOT NULL,
  "quantity" int NOT NULL,
    CONSTRAINT fk_product_id
        FOREIGN KEY(product_id)
            REFERENCES product(id)
            ON DELETE CASCADE
);

--  price в копейках
INSERT INTO product(id, name, category, price, image_url) VALUES(1, 'Джинсы классические', 'JEANS', '10000', 'https://ae04.alicdn.com/kf/Sbbee30b00cdf42778c48d5ac1e8b9e1bc.jpg_640x640.jpg');
INSERT INTO product(id, name, category, price, image_url) VALUES(2, 'Шорты', 'SHORTS', '15000', 'https://ir-3.ozone.ru/s3/multimedia-c/wc1000/6554599380.jpg');

INSERT INTO stock(product_id, size, quantity) VALUES(1, 'S', 5);
INSERT INTO stock(product_id, size, quantity) VALUES(1, 'M', 3);
INSERT INTO stock(product_id, size, quantity) VALUES(1, 'L', 8);

INSERT INTO stock(product_id, size, quantity) VALUES(2, 'S', 0);
INSERT INTO stock(product_id, size, quantity) VALUES(2, 'M', 0);
INSERT INTO stock(product_id, size, quantity) VALUES(2, 'L', 15);

